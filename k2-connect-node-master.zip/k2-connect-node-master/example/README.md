# k2-connect-node example

Ensure you have npm and node installed then:

```bash
npm install
```
Copy .env.example to a new file .env then replace the credentials with your own

To run the example app run the following command:

```bash
node main
```