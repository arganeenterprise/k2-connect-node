'use strict'

exports.TEST_ACCOUNT = {
	clientId: '1',
	clientSecret: '10af7ad062a21d9c841877f87b7dec3dbe51aeb3',
	apiKey: '8463vr8472a2372763787b7dec3dbe49879323gg32',
	baseUrl: 'https://9284bede-3488-4b2b-a1e8-d6e9f8d86aff.mock.pstmn.io',
}
