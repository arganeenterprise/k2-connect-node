module.exports.subscribeLocation = {
	location: 'https://sandbox.kopokopo.com/webhook_subscriptions/5af4c10a-f6de-4ac8-840d-42cb65454216',
	'Content-Type': 'application/json',
}
