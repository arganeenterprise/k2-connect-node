module.exports = {
	"topic": "buygoods_transaction_received",
	"id": "2133dbfb-24b9-40fc-ae57-2d7559785760",
	"created_at": "2020-10-22T10:43:20+03:00",
	"event": {
		"type": "Buygoods Transaction",
		"resource": {
			"id": "458712f-gr76y-24b9-40fc-ae57-2d35785760",
			"amount": "100.0",
			"status": "Received",
			"system": "Lipa Na M-PESA",
			"currency": "KES",
			"reference": "OJM6Q1W84K",
			"till_number": "514459",
			"sender_phone_number": "+254999999999",
			"origination_time": "2020-10-22T10:43:19+03:00",
			"sender_last_name": "Doe",
			"sender_first_name": "Jane",
			"sender_middle_name": null
		}
	},
	"_links": {
		"self": "https://sandbox.kopokopo.com/webhook_events/2133dbfb-24b9-40fc-ae57-2d7559785760",
		"resource": "https://sandbox.kopokopo.com/financial_transaction/458712f-gr76y-24b9-40fc-ae57-2d35785760"
	}
}
