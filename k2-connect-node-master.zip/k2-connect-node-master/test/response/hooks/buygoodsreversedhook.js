module.exports = {
	"topic": "buygoods_transaction_reversed",
	"id": "98adf21e-5721-476a-8643-609b4a6513a2",
	"created_at": "2020-10-29T08:06:49+03:00",
	"event": {
		"type": "Buygoods Transaction",
		"resource": {
			"id": "86345adf21e-5721-476a-8643-609b4a863",
			"amount": "233",
			"status": "Reversed",
			"system": "Lipa Na Mpesa",
			"currency": "KES",
			"reference": "OJM6Q1W84K",
			"till_number": "125476",
			"origination_time": "2020-10-29T08:06:49+03:00",
			"sender_last_name": "Doe",
			"sender_first_name": "Jane",
			"sender_middle_name": "",
			"sender_phone_number": "+254999999999"
		}
	},
	"_links": {
		"self": "https://sandbox.kopokopo.com/webhook_events/98adf21e-5721-476a-8643-609b4a6513a2",
		"resource": "https://sandbox.kopokopo.com/financial_transaction/86345adf21e-5721-476a-8643-609b4a863"
	}
}
