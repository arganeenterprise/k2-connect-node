module.exports = {
	"topic": "b2b_transaction_received",
	"id": "bcfb7175-bc7f-46e8-9727-eb46e6f88ef1",
	"created_at": "2020-10-29T08:18:45+03:00",
	"event": {
		"type": "External Till to Till Transaction",
		"resource": {
			"id": "fbygwu7175-bc7f-46e8-9727-f88edyy",
			"amount": "313",
			"status": "Complete",
			"system": "Lipa Na Mpesa",
			"currency": "KES",
			"reference": "OJQ8USH5XK",
			"till_number": "461863",
			"sending_till": "890642",
			"origination_time": "2020-10-29T08:18:45+03:00"
		}
	},
	"_links": {
		"self": "https://sandbox.kopokopo.com/webhook_events/bcfb7175-bc7f-46e8-9727-eb46e6f88ef1",
		"resource": "https://sandbox.kopokopo.com/financial_transaction/fbygwu7175-bc7f-46e8-9727-f88edyy"
	}
}
