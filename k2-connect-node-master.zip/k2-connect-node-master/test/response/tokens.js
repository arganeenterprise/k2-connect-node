module.exports.tokenResponse = {
	token_type: 'Bearer',
	expires_in: 3600,
	access_token: '0Sn0W6kzNicvoWhDbQcVSKLRUpGjIdlPSEYyrHqrDDoRnQwE7Q',
}

module.exports.introspectResponse = {
	active: true,
	scope: "",
	client_id: "lN19fbMMiWlJM0ekQMD4jGbO1jv2LzDXBi4wkGxHypg",
	token_type: "Bearer",
	exp: "2021-04-01T10:10:36+03:00",
	iat: "2021-04-01T09:10:36+03:00"
}

module.exports.infoResponse = {
	resource_owner_id: null,
	scope: [],
	expires_in: 2776,
	application: {
		uid: "lN19fbMMiWlJM0ekQMD4jGbO1jv2LzDXBi4wkGxHypg"
	},
	created_at: 1617257436
}

