module.exports.location = {
	location: 'https://sandbox.kopokopo.com/transaction_sms_notifications/5af4c10a-f6de-4ac8-840d-42cb65454216',
	'Content-Type': 'application/json',
}
module.exports.status = {
	"data": {
		"id": "9dfd9772-ce1c-4104-a12f-ca550d1b2bdf",
		"type": "transaction_sms_notification",
		"attributes": {
			"status": "Success",
			"message": "Your message here",
			"webhook_event_reference": "ee9df9c4-b637-4a9d-bf49-df1af0c61387",
			"_links": {
				"callback_url": "https://webhook.site/251982d5-0400-47a5-9ac5-736acf756a54",
				"self": "https://sandbox.kopokopo.com/api/v1/transaction_sms_notifications/9dfd9772-ce1c-4104-a12f-ca550d1b2bdf"
			}
		}
	}
}